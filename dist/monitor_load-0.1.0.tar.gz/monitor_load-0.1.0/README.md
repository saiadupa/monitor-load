# monitor-load

A CLI tool to monitor system load and pause/resume a process.

## Installation
Install via pip:
```sh
pip install monitor-load
